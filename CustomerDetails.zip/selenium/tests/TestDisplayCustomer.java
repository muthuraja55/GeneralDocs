package com.selenium.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.selenium.pages.CustomerForm;
import com.selenium.pages.DisplayCustomer;
import com.selenium.setup.DriverSetup;
import com.selenium.setup.ExcelUtils;

// fill the code
public class TestDisplayCustomer extends DriverSetup{

	WebDriver driver;
    CustomerForm customerForm;
	DisplayCustomer displayCustomer;
	public static String titletxt;
	public static String customerNametxt;
	public static String agetxt;
	public static String addresstxt;
	public static String numbertxt;
	public static String emailtxt;
 
	
// fill the code
	@BeforeClass
	public void setUp() {
		driver = getDriver();
		displayCustomer= new DisplayCustomer(driver);
		customerForm=new CustomerForm(driver);
	}
	
		// fill the code
	@Test(dataProvider="customervalid")
	public void testValidCustomerDetails(String customerName, String age,String address,String phoneNumber,String email) {
		// fill the code
		customerForm.setCustomerName(customerName);
		customerForm.setAge(age);
		customerForm.setAddress(address);	
		customerForm.setPhoneNumber(phoneNumber);
		customerForm.setEmail(email);
		customerForm.submitForm();
		
		titletxt = displayCustomer.getTitle();
		customerNametxt = displayCustomer.getName();
		agetxt = displayCustomer.getAge();
		addresstxt = displayCustomer.getAddress();
		numbertxt = displayCustomer.getPhoneNumber();
		emailtxt = displayCustomer.getEmail();
		
		
}
	
	@DataProvider(name="customervalid")
	public Object[][] getExcelData() throws Exception {			
		// fill the code
		Object[][] testarray = ExcelUtils.readExcelData("customer_valid");
		return(testarray);
	}
	
	@AfterClass
	public void closeBrowser(){
		driver.close();
	}
	
	
	
	
}
