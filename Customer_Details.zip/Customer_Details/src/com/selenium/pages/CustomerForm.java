package com.selenium.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerForm {
	// fill the code
	
	WebDriver driver;
	
	public CustomerForm (WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy (xpath="//input[@name='cname']")
	WebElement customerName;
	
	@FindBy (xpath="//input[@name='age']")
	WebElement age;
	
	@FindBy (xpath="//input[@name='address']")
	WebElement address;
	
	@FindBy (xpath="//input[@name='phonenumber']")
	WebElement phonenumber;
	
	@FindBy (xpath="//input[@name='email']")
	WebElement email;
	
	@FindBy (id="submit")
	WebElement submitButton;
	
	@FindBy (xpath="//div[@id='message']")
	WebElement errorMessage;
	
	
	public void setCustomerName(String cName){	
		customerName.sendKeys(cName);
	}
	
	public void setAge(String age){	
		this.age.sendKeys(age);
	}
	
	public void setAddress(String address){	
		this.address.sendKeys(address);
	}
	
	public void setPhoneNumber(String phoneNumber){	
		this.phonenumber.sendKeys(phoneNumber);
	}
	
	public void setEmail(String email){	
		this.email.sendKeys(email);
	}
	
	public void submitForm(){	
		this.submitButton.click();
	}
	
	public String getErrorMessage(){	
		return this.errorMessage.getText();
	}
	
	
	
}
