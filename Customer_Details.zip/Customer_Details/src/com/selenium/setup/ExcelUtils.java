package com.selenium.setup;



import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
    private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	
	private static XSSFCell cell;
	private static XSSFRow row;

	private static FileInputStream excelFile;
	private static String filePath;


public static Object[][] readExcelData(String sheetName) throws Exception {
	String[][] arrayExcelData = null;
	
			String workingDir = System.getProperty("user.dir");
			filePath = workingDir+File.separator+"src"+File.separator+"customer_registration.xlsx";
			excelFile = new FileInputStream(filePath);
            ExcelWBook = new XSSFWorkbook(excelFile);
		    ExcelWSheet = ExcelWBook.getSheet(sheetName);
		   	// fill the code
		    
		    int RowNum = ExcelWSheet.getLastRowNum();
		    
		    int ColNum = 5;
		    int ci,cj;
		    
		    arrayExcelData = new String[RowNum][ColNum];
		    
		    ci=0;
		    
		    for(int i=1;i<=RowNum;i++,ci++){
		    	
		    	cj=0;
		    	
		    	row = ExcelWSheet.getRow(i);
		    	
		    	for(int j=1;j<=ColNum;j++,cj++){
		    		
		    		cell = row.getCell(j);
		    		
		    		arrayExcelData[ci][cj]=cell.getStringCellValue().toString();
		    				 
		    	}    	
		    	
		    	
		    }
return arrayExcelData;

}





}
