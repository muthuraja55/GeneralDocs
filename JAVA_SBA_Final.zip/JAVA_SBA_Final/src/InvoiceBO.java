import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
public class InvoiceBO {

	public List<Invoice> getAllInvoice() throws ClassNotFoundException, SQLException 
	{
		return getAllInvoice();		
	}
	public void updateInvoiceDetails(int id,Double amount) 
	{
		//fill the code
		updateInvoiceDetails(id, amount);
	}
	
}
