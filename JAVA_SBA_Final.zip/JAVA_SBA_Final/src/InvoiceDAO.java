import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

// fill the code
public class InvoiceDAO {

	public List<Invoice> getAllInvoices() throws ClassNotFoundException, SQLException
	{
		// fill the code
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection conn=DbConnection.getConnection();
		java.sql.Statement stmt=conn.createStatement();
		String query="select * from invoice;";
		ResultSet rs=stmt.executeQuery(query);
		List<Invoice> allinvocies = new ArrayList<Invoice>();
		
		while(rs.next())
		{
			allinvocies.add(new Invoice(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getDouble(5),rs.getString(6)));
		}
		
		conn.close();
		return allinvocies;
	}
	
	public void updateInvoiceDetails(Integer invoiceId, Double amount) throws ClassNotFoundException, SQLException
	{	
		java.sql.Connection conn=DbConnection.getConnection();
		java.sql.Statement stmt=conn.createStatement();
		try
		{
			String query2="update invoice set payment_attempts=payment_attempts+1 where id="+invoiceId+";";		
			stmt.executeUpdate(query2);
			
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		String query3="update invoice set balance=balance - "+amount+" where id="+invoiceId+";";
		stmt.executeUpdate(query3);	
	}
	
	public Double getBalanceAfterDeductionAmount(Integer invoiceId) throws ClassNotFoundException, SQLException
	{		
		
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection conn=DbConnection.getConnection();
		java.sql.Statement stmt=conn.createStatement();
		String query5="select balance from invoice where id="+invoiceId+";";
		ResultSet rs=stmt.executeQuery(query5);
		try
		{	rs.next();				
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return rs.getDouble(1);
	}	
	
}
