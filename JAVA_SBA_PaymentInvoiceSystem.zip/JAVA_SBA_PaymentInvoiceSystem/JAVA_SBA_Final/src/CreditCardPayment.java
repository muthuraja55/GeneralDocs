import com.mysql.jdbc.StringUtils;


public class CreditCardPayment extends Payment 
{

	private String cardNumber;
	private String cvv;
	private String cardName;
	
	public CreditCardPayment() 
	{
		
	}
	public CreditCardPayment(String name, Double amount, String cardNumber, String cvv, String cardName) 
	{
		super(name, amount);
		this.cardNumber = cardNumber;
		this.cvv = cvv;
		this.cardName = cardName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	
	public Double calculateTotalAmount()throws InvalidPaymentException  
	{		
		Double dblTemp=0.0;
		if((cardNumber.matches("[0-9]+")) && (cardNumber.length()==16))
		{
				if((cvv.matches("[0-9]+")) && (cvv.length()==3))
				{
					Double t= amount*0.1;
					dblTemp=amount + t;
				}
				else
				{
					throw new InvalidPaymentException("InvalidPaymentException: Invalid Card Details");				
				}
		}
		else
		{
			throw new InvalidPaymentException("InvalidPaymentException: Invalid Card Details");			
		}
		
		return dblTemp;
	}	
	
}
