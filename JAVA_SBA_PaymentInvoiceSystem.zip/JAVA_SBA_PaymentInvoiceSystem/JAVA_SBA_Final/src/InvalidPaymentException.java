
public class InvalidPaymentException extends Exception 
{
	InvalidPaymentException(String e)
	{
		super(e);
	}
}
