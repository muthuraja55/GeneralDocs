import java.sql.SQLException; 

import java.util.List;   

public interface IPaymentDAO{   

public void insertPaymentDetails(List<Cheque>chequeList)throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException; 

  

} 