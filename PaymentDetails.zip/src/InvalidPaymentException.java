
public class InvalidPaymentException extends Exception{

    //fill the code
	public InvalidPaymentException(String s) 

	{ 

	super(s); 

	} 

		
}