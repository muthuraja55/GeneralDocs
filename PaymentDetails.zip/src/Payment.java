
public class Payment { 
	
	Integer id;
	String customerName;
    String	invoiceNumber;
	Integer attempt;
	Double  amount;
	String status;
	
	public Payment(Integer id, String customerName, String invoiceNumber,
		Integer attempt, Double amount,String status) {
		this.id = id;	       
		this.customerName = customerName;
		this.invoiceNumber = invoiceNumber;
		this.attempt = attempt;					
		this.amount = amount;
		this.status = status;		
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public Integer getAttempt() {
		return attempt;
	}
	public void setAttempt(Integer attempt) {
		this.attempt = attempt;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
		
}
