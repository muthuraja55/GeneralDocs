drop database if exists payment;
create database payment;
use payment;
drop table if exists cheque;
drop table if exists payment;

create table payment
(id int not null,
customer_name varchar(20),
invoice_number varchar(20),
attempt int,
amount double,
status varchar(30),
primary key(id));


create table cheque
(id int not null primary key,
bank_name varchar(20),
cheque_number varchar(20),
payment_id int,
foreign key(payment_id)
references payment(id));
