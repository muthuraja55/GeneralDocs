
import static org.junit.Assert.fail;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
 
public class WebTest {
    private WebDriver driver;
    public static String baseUrl;
    private boolean acceptNextAlert = true;
    private StringBuffer verificationErrors = new StringBuffer();
	static String result1;
	static String result2;
	static String result3;
	static String result4;
	static String result5;
	static String result6;
 
    @Before
    public void setUp() throws Exception {
    	//System.setProperty("webdriver.chrome.driver","D:\\Development_Avecto\\chromedriver.exe");
        //driver = new ChromeDriver();
    	driver = new FirefoxDriver();
	    driver.manage().window().maximize();
        baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/CompanyOffersDiscount/";
        driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
    }
 
    @Test
    public void testWeb() throws Exception {
        //driver.get(baseUrl + "/index.html");
    	driver.get(baseUrl);
		String weight1="100";
		String weight2="80";
		String weight3="60";
		String weight4="120";
		String weight5="300";
		String weight6="50";
		
		String distance1="200";
		String distance2="500";
		String distance3="110";
		String distance4="520";
		String distance5="200";
		String distance6="150";
		By weightTextBox = By.xpath("//input[@id='weight']");
		By distanceTextBox = By.xpath("//input[@id='distance']");
		By submitButton = By.xpath("//button[@id='submit']");
		
		//1 : Application launch
		if(isElementPresent(weightTextBox)){
			System.out.println("Step1 : Application was successfully launched");	
		}else{
			System.out.println("Step1 : Application was not launched");
		};
		
		
		//2 : Check for the input,weight : 100,distance : 200
		driver.findElement(weightTextBox).sendKeys(weight1);
		driver.findElement(distanceTextBox).sendKeys(distance1);
		driver.findElement(submitButton).click();
		
		Thread.sleep(2000);
		By textMessage1 = By.xpath("//div[@id='result' and text()='Datax shipping company offers discount']");
		
		if(isElementPresent(textMessage1)){
			System.out.println("Step2 : The Text 'Datax shipping company offers discount' was dispayed");	
		}else{
			System.out.println("Step2 : The Text 'Datax shipping company offers discount' was not dispayed");
		};
		
		
		//3 : 	Create a static variable named as result1(String) and store the string into the variable.
		result1 = driver.findElement(textMessage1).getText();
		System.out.println("result1: "+result1);
		
		//4 : Check for the input,weight : 80,distance : 500
		driver.findElement(weightTextBox).clear();
		driver.findElement(distanceTextBox).clear();
		driver.findElement(weightTextBox).sendKeys(weight2);
		driver.findElement(distanceTextBox).sendKeys(distance2);
		driver.findElement(submitButton).click();

		Thread.sleep(2000);
		if(isElementPresent(textMessage1)){
			System.out.println("Step3 : The Text 'Datax shipping company offers discount' was dispayed");	
		}else{
			System.out.println("Step3 : The Text 'Datax shipping company offers discount' was not dispayed");
		};
		
		//5 : 	Create a static variable named as result2(String) and store the string into the variable.
		result2 = driver.findElement(textMessage1).getText();
		System.out.println("result2: "+result2);
		
				
		//6 : Check for the input,weight : 60,distance : 110
		driver.findElement(weightTextBox).clear();
		driver.findElement(distanceTextBox).clear();
		driver.findElement(weightTextBox).sendKeys(weight3);
		driver.findElement(distanceTextBox).sendKeys(distance3);
		driver.findElement(submitButton).click();
		
		Thread.sleep(2000);
		By textMessage2 = By.xpath("//div[@id='result' and text()='Datax shipping offers no discount']");
		
		Thread.sleep(2000);
		if(isElementPresent(textMessage2)){
			System.out.println("Step4 : The Text 'Datax shipping offers no discount' was dispayed");	
		}else{
			System.out.println("Step4 : The Text 'Datax shipping offers no discount' was not dispayed");
		};
		
		//7 : 	Create a static variable named as result3(String) and store the string into the variable.
		result3 = driver.findElement(textMessage2).getText();
		System.out.println("result3: "+result3);
		
		//8 : Check for the input,weight : 60,distance : 110
		driver.findElement(weightTextBox).clear();
		driver.findElement(distanceTextBox).clear();
		driver.findElement(weightTextBox).sendKeys(weight4);
		driver.findElement(distanceTextBox).sendKeys(distance4);
		driver.findElement(submitButton).click();
		
		Thread.sleep(2000);
		
		Thread.sleep(2000);
		if(isElementPresent(textMessage1)){
			System.out.println("Step5 : The Text 'Datax shipping company offers discount' was dispayed");	
		}else{
			System.out.println("Step5 : The Text 'Datax shipping company offers discount' was not dispayed");
		};
		
		//9 : 	Create a static variable named as result3(String) and store the string into the variable.
		result4 = driver.findElement(textMessage1).getText();
		System.out.println("result4: "+result4);
		
		//10 : Check for the input,weight : 60,distance : 110
		driver.findElement(weightTextBox).clear();
		driver.findElement(distanceTextBox).clear();
		driver.findElement(weightTextBox).sendKeys(weight5);
		driver.findElement(distanceTextBox).sendKeys(distance5);
		driver.findElement(submitButton).click();
		
		Thread.sleep(2000);
		
		Thread.sleep(2000);
		if(isElementPresent(textMessage1)){
			System.out.println("Step6 : The Text 'Datax shipping company offers discount' was dispayed");	
		}else{
			System.out.println("Step6 : The Text 'Datax shipping company offers discount' was not dispayed");
		};
		
		//11 : 	Create a static variable named as result3(String) and store the string into the variable.
		result5 = driver.findElement(textMessage1).getText();
		System.out.println("result5: "+result5);
		
		
		//12 : Check for the input,weight : 60,distance : 110
		driver.findElement(weightTextBox).clear();
		driver.findElement(distanceTextBox).clear();
		driver.findElement(weightTextBox).sendKeys(weight6);
		driver.findElement(distanceTextBox).sendKeys(distance6);
		driver.findElement(submitButton).click();
		
		Thread.sleep(2000);
		if(isElementPresent(textMessage2)){
			System.out.println("Step7 : The Text 'Datax shipping offers no discount' was dispayed");	
		}else{
			System.out.println("Step7 : The Text 'Datax shipping offers no discount' was not dispayed");
		};
		
		//13 : 	Create a static variable named as result3(String) and store the string into the variable.
		result6 = driver.findElement(textMessage2).getText();
		System.out.println("result6: "+result6);
		
		System.out.println("End of Program");
		

    }
 
    @After
    public void tearDown() throws Exception {
 
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }
 
    private boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }
 
    private boolean isAlertPresent() {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
    }
 
    private String closeAlertAndGetItsText() {
        try {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            if (acceptNextAlert) {
                alert.accept();
            } else {
                alert.dismiss();
            }
            return alertText;
        } finally {
            acceptNextAlert = true;
        }
    }
}
