import java.util.regex.Pattern;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;

public class WebTest {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  Integer passCount=0;
  Integer totalCount=14;
  private StringBuffer verificationErrors = new StringBuffer();
  static WebElement thelement,trelement,tdelement,resultId,myTableId,h2element;
  static WebElement nameText,number,genderRadio,date,degreeSelect,cProgramCheckBox,abtUtextarea,submit,sslc,hsc,ug;
  static WebElement eligible,notEligible;
  static String url;

  
  @Before
  public void setUp() throws Exception {
	   //System.setProperty("webdriver.chrome.driver","D:\\Development_Avecto\\chromedriver.exe"); 
	   //driver = new ChromeDriver();
	   driver = new FirefoxDriver();
	   baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/Registration/";
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.MILLISECONDS);
  }
  
  @Test
  public void testWeb() throws Exception {
	    driver.get(baseUrl);	
	//fill your code
	    
	    nameText = driver.findElement(By.id("name"));
	    number = driver.findElement(By.id("age"));
	    genderRadio = driver.findElement(By.id("gender"));
	    date = driver.findElement(By.id("dob"));
	    degreeSelect = driver.findElement(By.id("degree"));
	    cProgramCheckBox = driver.findElement(By.id("c"));
	    abtUtextarea = driver.findElement(By.id("aboutYou"));
	    submit = driver.findElement(By.id("submit"));
	    
	    sslc = driver.findElement(By.id("sslc"));
	    hsc = driver.findElement(By.id("higher"));
	    ug = driver.findElement(By.id("ug"));
	    
	        
		//1 : Text box should be present with id name
        if (nameText.isDisplayed()){
		System.out.println("Step1 : Text box was present with id name"); };
        
		//2 : Number format should be present with id age
        if (number.isDisplayed()){
		System.out.println("Step2 : Number format was present with id age"); };
        
		//3 : Radio button should be present with id gender
        if (genderRadio.isDisplayed()){
		System.out.println("Step3 : Radio button was present with id gender"); };
        
		//4 : The type date  should be present with id dob
        if (date.isDisplayed()){
		System.out.println("Step4 : The type date was present with id dob"); };
        
		//5 : Drop down menu should be present with id degree
        if (degreeSelect.isDisplayed()){
		System.out.println("Step5 : Drop down menu was present with id degree");};        
        
		//5 : Checkbox should be present with id c
        if (cProgramCheckBox.isDisplayed()){
		System.out.println("Step6 : Checkbox was present with id c");};        
        
		//6 : Text area should be present with id aboutYou
        if (submit.isDisplayed()){
		System.out.println("Step7 : Text area was present with id aboutYou"); };
        
		//7 : Text area should be present with id aboutYou
        if (abtUtextarea.isDisplayed()){
		System.out.println("Step8 : Text area was present with id aboutYou");
        };
        
		//8 : 	The button should be present with id submit
        if (abtUtextarea.isDisplayed()){
		System.out.println("Step9 : The button was present with id submit");
        };
	    
	    //9 
	    nameText.sendKeys("Sri");
	    number.sendKeys("21");
	    genderRadio.sendKeys("Male");
	    degreeSelect.sendKeys("BE");
	    sslc.sendKeys("80");
	    hsc.sendKeys("80");
	    ug.sendKeys("70");
	    cProgramCheckBox.click();
	    abtUtextarea.sendKeys("Hard worker");
	    submit.click();
	    
	    eligible = driver.findElement(By.id("message"));
	    
	    //10 : 	The message "You are eligible for this Interview" should be present in the div id message
        if (eligible.isDisplayed()){
		System.out.println("Step10 : 'The message You are eligible for this Interview' was present in the div id message");
        };
        
	    //11 
	    nameText.sendKeys("Suriya");
	    number.sendKeys("21");
	    genderRadio.sendKeys("Male");
	    degreeSelect.sendKeys("BE");
	    sslc.sendKeys("80");
	    hsc.sendKeys("40");
	    ug.sendKeys("30");
	    cProgramCheckBox.click();
	    abtUtextarea.sendKeys("Hard worker");
	    submit.click();
	    
	    notEligible = driver.findElement(By.id("message"));
	    
	    //12 : 	The message "Sorry, you are not-eligible for this Interview" should be present in the div id message
        if (eligible.isDisplayed()){
		System.out.println("Step11 : 'The message Sorry, you are not-eligible for this Interview' was present in the div id message");
        };
        
        
        
  }

@After
  public void tearDown() throws Exception {
  
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
