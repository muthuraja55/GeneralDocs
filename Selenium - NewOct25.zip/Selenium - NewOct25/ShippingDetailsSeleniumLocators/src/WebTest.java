

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;


public class WebTest {
    private WebDriver driver;
    private String baseUrl;
    private boolean acceptNextAlert = true;
    private StringBuffer verificationErrors = new StringBuffer();

    public static  String url, h2tag, link1, link2, link3, tablecontent1,
    tablecontent2, result1, result2, result3;

    @Before
    public void setUp() throws Exception {
    	//System.setProperty("webdriver.chrome.driver","D:\\Development_Avecto\\chromedriver.exe");
        //driver = new ChromeDriver();
        driver = new HtmlUnitDriver(true);
        baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/shippingDetails/";
        driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
    }


    @Test
    public void testWeb() throws Exception {
        
        driver.get(baseUrl + "/index.html");
         //fill your code

	    
	    Thread.sleep(3000);
	    h2tag = driver.findElement(By.xpath("//h2")).getText();
	    link1 = driver.findElement(By.linkText("6543217")).getText();
	    WebElement ShipmentId = driver.findElement(By.linkText("6543217"));
	    //link2 = driver.findElement(By.linkText("7465328")).getText();
	    //link3 = driver.findElement(By.linkText("9987653")).getText();
	   
		//1 : Application launch
	    
	 	 
		assertEquals(h2tag,"Shipping Details");
		System.out.println("Step1 : h2tag was displayed");
		System.out.println("Step1 : Application was successfully launched");
				
		
		//2 : 	Check for the input	Air : 100 click calculate button
		ShipmentId.click();
		
		tablecontent1 = driver.findElement(By.xpath("//table[@style='border collapse:collapse;width:400px;height:300px']/tbody/tr/td[text()='Maya']")).getText();
		String shipmentDate = driver.findElement(By.xpath("//td[text()='Shipping Date : 03/12/2017']")).getText();
		String accountno = driver.findElement(By.xpath("//td[text()='Account No : 93746537']")).getText();
		    		
		
		//3
		assertEquals(tablecontent1,"Maya");
		System.out.println("Step2 : Text 'Maya' was displayed");
		result1=tablecontent1;
		//4
		assertEquals(shipmentDate,"Shipping Date : 03/12/2017");
		System.out.println("Step3 : Shipping Date : 03/12/2017 was displayed");
		result2=shipmentDate;
		
		//5
		assertEquals(accountno,"Account No : 93746537");
		System.out.println("Step4 : Account No : 93746537 was displayed");
		result3=accountno;
		
		System.out.println("End of program");
		driver.close();
  }

    @After
    public void tearDown() throws Exception {

        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    private boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    private boolean isAlertPresent() {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
    }

    private String closeAlertAndGetItsText() {
        try {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            if (acceptNextAlert) {
                alert.accept();
            } else {
                alert.dismiss();
            }
            return alertText;
        } finally {
            acceptNextAlert = true;
        }
    }
}
