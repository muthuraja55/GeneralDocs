

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebTest {
    private WebDriver driver;
    public static String baseUrl;
    private boolean acceptNextAlert = true;
    private StringBuffer verificationErrors = new StringBuffer();
	
	  static WebElement signupId;
	  static WebElement loginId;
	  static WebElement h1element;
	  static WebElement h2element;
	  static WebElement h3element;
	  static WebElement pelement;


	    @Before
	    public void setUp() throws Exception {
	    	//System.setProperty("webdriver.chrome.driver","D:\\Development_Avecto\\chromedriver.exe");
	        //driver = new ChromeDriver();
	    	driver = new FirefoxDriver();
		    driver.manage().window().maximize();
	        baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/HTMLTAGS/";
	        driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	    }
	    
	    @Test
		public void testWeb() throws Exception {		
		driver.get(baseUrl);
		Thread.sleep(5000);
		
		h1element = driver.findElement(By.xpath("//h1[text()='DATAX Shipping Company']"));
		h2element = driver.findElement(By.xpath("//h2[text()='Welcome to DATAX Shipping Company']"));
		h3element = driver.findElement(By.xpath("//h3[text()='About us :']"));
		pelement = driver.findElement(By.xpath("//p[contains(text(),'DATAX Shipping Company')]"));
		signupId = driver.findElement(By.id("signup"));
		loginId = driver.findElement(By.id("login"));
		
				
		if(h1element.isDisplayed()){
			System.out.println("Step1 : h1 element was displayed 'DATAX Shipping Company'");	
		}else{
			System.out.println("Step1 : h1 element was not displayed 'DATAX Shipping Company'");
		};
		
		String h1elementTXT = h1element.getText();		 
		assertEquals(h1elementTXT,"DATAX Shipping Company");
		System.out.println("Step1 : h1 element was displayed 'DATAX Shipping Company'");	
			
		if(h2element.isDisplayed()){
			System.out.println("Step2 : h2 element was displayed 'Welcome to DATAX Shipping Company'");	
		}else{
			System.out.println("Step2 : h2 element was not displayed 'Welcome to DATAX Shipping Company'");
		};
		
		if(h3element.isDisplayed()){
			System.out.println("Step3 : h3 element was displayed 'About us :'");	
		}else{
			System.out.println("Step3 : h3 element was not displayed 'About us :'");
		};
		
		if(pelement.isDisplayed()){
			System.out.println("Step4 : p tag was displayed.");	
		}else{
			System.out.println("Step4 : p tag was not displayed.");
		};
		
		if(signupId.isDisplayed()){
			System.out.println("Step5 : signupId link was displayed.");	
		}else{
			System.out.println("Step5 : signupId link was not displayed.");
		};
		
		if(loginId.isDisplayed()){
			System.out.println("Step6 : loginId link was displayed.");	
		}else{
			System.out.println("Step6 : loginId link was not displayed.");
		}
		
		System.out.println("End of Program");
		driver.close();
	    }
		
		
		@After
		  public void tearDown() throws Exception {
			 // System.out.println("#"+Math.round((passCount/(float)totalCount)*100));
		    driver.quit();
		    String verificationErrorString = verificationErrors.toString();
		    if (!"".equals(verificationErrorString)) {
		      fail(verificationErrorString);
		    }
		  }

		  private boolean isElementPresent(By by) {
		    try {
		      driver.findElement(by);
		      return true;
		    } catch (NoSuchElementException e) {
		      return false;
		    }
		  }

		  private boolean isAlertPresent() {
		    try {
		      driver.switchTo().alert();
		      return true;
		    } catch (NoAlertPresentException e) {
		      return false;
		    }
		  }

		  private String closeAlertAndGetItsText() {
		    try {
		      Alert alert = driver.switchTo().alert();
		      String alertText = alert.getText();
		      if (acceptNextAlert) {
		        alert.accept();
		      } else {
		        alert.dismiss();
		      }
		      return alertText;
		    } finally {
		      acceptNextAlert = true;
		    }
		  }
				
		
	

}
