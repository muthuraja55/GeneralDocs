package com.selenium.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DisplayCustomer {
		// fill the code
	
WebDriver driver;
	
	public DisplayCustomer (WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	
	@FindBy (xpath="(//td)[02]")
	WebElement name;
	
	@FindBy (xpath="(//td)[04]")
	WebElement age;
	
	@FindBy (xpath="(//td)[06]")
	WebElement address;
	
	@FindBy (xpath="(//td)[08]")
	WebElement phoneNumber;
	
	@FindBy (xpath="(//td)[10]")
	WebElement email;
	
	@FindBy (xpath="//h2")
	WebElement title;
	

	public String getTitle(){
		return title.getText();
	}
	
	public String getName(){
		return name.getText();
	}
	
	public String getAge(){
		return age.getText();
	}
	
	public String getEmail(){
		return email.getText();
	}
	
	public String getAddress(){
		return address.getText();
	}
	
	public String getPhoneNumber(){
		return phoneNumber.getText();
	}
}

