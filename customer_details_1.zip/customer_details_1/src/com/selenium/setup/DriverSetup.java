package com.selenium.setup;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverSetup {
	private WebDriver driver;
	public static String baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/CustomerRegistration/";
	
	public WebDriver getDriver() {

		System.setProperty("webdriver.chrome.driver", "D://Development_Avecto//chromedriver_win32_new//chromedriver.exe");
	    //driver = new FirefoxDriver();
		driver = new ChromeDriver();
		driver.navigate().to(DriverSetup.baseUrl);
		return driver;
	}
}
