package com.selenium.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.selenium.pages.CustomerForm;
import com.selenium.setup.ExcelUtils;
import com.selenium.setup.DriverSetup;
		// fill the code
public class TestCustomerForm extends DriverSetup{

	WebDriver driver;
	CustomerForm customerForm;
	static public String blankErrtxt;
 
	@BeforeClass	
	// fill the code
	public void setUp() {
		driver = getDriver();
	    customerForm= new CustomerForm(driver);
	}
	
	@Test(dataProvider="customerInvalid")
	public void testInvalidCustomerDetails(String customerName, String age,String address,String phoneNumber,String email) {
	
		// fill the code
		customerForm.setCustomerName(customerName);
		customerForm.setAge(age);
		customerForm.setAddress(address);	
		customerForm.setPhoneNumber(phoneNumber);
		customerForm.setEmail(email);
		customerForm.submitForm();
		blankErrtxt = customerForm.getErrorMessage();
    }
	
        // fill the code
	@DataProvider(name="customerInvalid")
	public Object[][] getExcelData() throws Exception {		
		// fill the code
		return ExcelUtils.readExcelData("customer_invalid");
	}
	
		// fill the code
	@AfterClass
	public void closeBrowser(){
			driver.close();
	}
	
		
}
