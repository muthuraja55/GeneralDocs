package com.item.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ItemListPage {
       
       WebDriver driver;
       
       public ItemListPage(WebDriver driver){
              this.driver = driver;
              PageFactory.initElements(driver, this);
       }
       
       @FindBy(xpath="(//td)[2]")
       WebElement itemCode;
       
       @FindBy(xpath="(//td)[3]")
       WebElement itemName;
       
       @FindBy(xpath="(//td)[4]")
       WebElement itemPrice;
       
       @FindBy(xpath="(//td)[5]")
       WebElement itemDescription;
       
       @FindBy(xpath="//h4[contains(text(),'Item list is empty')]")
       WebElement emptyMessage;
       
       public String getItemCode(){
              return itemCode.getText();
       }
       
       public String getitemName(){
              return itemName.getText();
       }
       
       public String getitemPrice(){
              return itemPrice.getText();
       }
       
       public String getitemDescription(){
              return itemDescription.getText();
       }
       
       public String getemptyMessage(){
              return emptyMessage.getText();
       }
       
       
}
