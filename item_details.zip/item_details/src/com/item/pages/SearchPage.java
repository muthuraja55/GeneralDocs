package com.item.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.item.setup.DriverSetup;

public class SearchPage {
	// fill the code
	
	WebDriver driver;
	public SearchPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@name='category']")
	WebElement category;
	@FindBy(xpath = "//input[@name='startPrice']")
	WebElement startPrice;
	@FindBy(xpath = "//input[@name='endPrice']")
	WebElement endPrice;
	@FindBy(xpath = "//input[@id='search']")
	WebElement searchButton;
	@FindBy(xpath = "//h3[@id='errorMessage']")
	WebElement errorMessage;
	
	public  void setCategory(String iCategory){
		category.sendKeys(iCategory);
    }
	public void setStartPrice(String startPrice){
		this.startPrice.sendKeys(startPrice);
    }
	public void setEndPrice(String endPrice){
		this.endPrice.sendKeys(endPrice);
    }
	public String getErrorMessage(){
		
		return errorMessage.getText();
		
	}

	public void clickSearch(){
    	searchButton.click();
    }

	
}
